<?php

namespace App\Http\Controllers;

use App\Estate;
use Session;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EstateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $userid = Auth::id();
        $landlords = Estate::where('user_id', $userid)->paginate(2);
        return view('estates.index')->with('landlords', $landlords);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('estates.create');
    }

    public function search(Request $request)
    {
        $keyword = $request->word;
        $houses = Estate::where('address', 'like', '%' . $keyword . '%')
            ->orWhere('phone', 'like', '%' . $keyword . '%')
            ->orWhere(DB::raw("CONCAT(first_name, ' ', last_name)"), 'like', '%' . $keyword . '%')->paginate(5);
        return view('visitorsdashboard')->with('houses', $houses)->with('search', $keyword);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $this->validate($request, [
            'is_paid' => 'required',
            'land_id' => 'required',
            'has_mailbox' => 'required',
            'phone' => 'required',
            'email' => 'required',
            'last_name' => 'required',
            'first_name' => 'required',
            'address' => 'required',
        ]);

        if (Estate::where('land_id', $request->land_id)->exists()) {
            Session::flash('warning', 'This Apartment already exist in the database');
            return redirect()->back();
        } else {
            // $featured = $request->picture;
            // $featured_new_name = time().$featured->getClientOriginalName();
            // $featured->move('uploads/images', $featured_new_name);

            $save = Estate::create([
                'user_id' => Auth::id(),
                'land_id' => $request->land_id,
                'is_paid' => $request->is_paid,
                'has_mailbox' => $request->has_mailbox,
                'phone' => $request->phone,
                'email' => $request->email,
                'last_name' => $request->last_name,
                'first_name' =>  $request->first_name,
                'address' => $request->address,
            ]);


            Session::flash('success', 'Records successfully added');
            return redirect()->route('dashboard');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Estate  $estate
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Estate  $estate
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $estate = Estate::find($id);
        return view('estates.edit')->with('estate', $estate);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Estate  $estate
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $this->validate($request, [
            'is_paid' => 'required',
            'land_id' => 'required',
            'has_mailbox' => 'required',
            'phone' => 'required',
            'email' => 'required',
            'last_name' => 'required',
            'first_name' => 'required',
            'address' => 'required',
        ]);

        $estate = Estate::find($id);

        $estate->land_id = $request->land_id;
        $estate->is_paid = $request->is_paid;
        $estate->has_mailbox = $request->has_mailbox;
        $estate->phone = $request->phone;
        $estate->email = $request->email;
        $estate->last_name = $request->last_name;
        $estate->first_name =  $request->first_name;
        $estate->address = $request->address;

        $estate->save();


        Session::flash('success', 'Successfully Updated');
        return redirect()->route('dashboard');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Estate  $estate
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $estate = Estate::find($id);
        $estate->delete();
        Session::flash('warning', 'Estate removed successfully');
        return redirect()->back();
    }
}
