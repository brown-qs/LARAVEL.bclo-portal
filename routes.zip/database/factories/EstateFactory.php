<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Estate;
use Faker\Generator as Faker;

$factory->define(Estate::class, function (Faker $faker) {
    return [
        //
    ];
});
