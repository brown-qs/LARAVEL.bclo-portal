<?php

use Illuminate\Database\Seeder;

class EstatesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $user = App\Estate::create([
            'username'=> 'Billy Lowery',
            'password' => bcrypt('wubur'),
        ]);

        $user = App\User::create([
            'username'=> 'William Passmore',
            'password' => bcrypt('wubur'),
        ]);

        $user = App\User::create([
            'username'=> 'James Ferry',
            'password' => bcrypt('wubur'),
        ]);
    
    }
}
