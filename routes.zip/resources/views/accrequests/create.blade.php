<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>BCLO</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <script src="{{asset('js/jquery-2.1.3.min.js')}}"></script>
    <script src="{{asset('assets/js/materialize.min.js')}}"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="{{asset('assets/css/font-awesome.min.css')}}">
    <!-- Styles -->

    <link href="{{asset('assets/css/materialize.min.css')}}" rel="stylesheet">
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{asset('assets/css/style.css')}}" rel="stylesheet">
    <link href="{{ asset('css/toastr.min.css') }}" rel="stylesheet">

</head>

<body>
    @include('includes.nav')
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 m-auto">
                    <a href="{{route('frontend.singlehouse', ['id'=>$estate->id])}}" class="btn btn-lg btn-default">Back to Estate</a>
                    <div class="card">
                        <div class="card-header text-center">
                            <h4 class="card-title">Add your Request</h4>
                        </div>

                        <div class="card-body">
                            <form action="{{route('accrequest.store', ['id'=>$estate->id])}}" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="input-field">
                                    <input type="text" name="name" value="{{Auth::user()->name}}" disabled>
                                </div>

                                <input type="hidden" name="estate_id" value="{{$estate->id}}">

                                <div class="input-field">
                                    <input type="file" name="file" class="form-control @error('file') is-invalid @enderror" placeholder="file">
                                    @error('file')
                                    <span class="invalid-feedback">
                                        <strong>{{$message}}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <textarea name="note" class="form-control @error ('note') is-invalid @enderror" placeholder="Leave Note here....">{{old('note')}}</textarea>

                                    @error('note')
                                    <div class="invalid-feedback">
                                        <strong>{{$message}}</strong>
                                    </div>
                                    @enderror
                                </div>

                                <div class="input-field">
                                    <button class="btn light-blue darken-1 white-text">

                                        Send Request
                                    </button>
                                </div>
                            </form>
                            <hr>
                            <h3 class="light-blue-text center">{{$estate->first_name . ' ' . $estate->last_name}}</h3>
                            <hr>
                            @foreach($comments as $comment)
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item mb-2">
                                    <a download href="{{asset('uploads/files/'.$comment->file)}}">{{$comment->file}}</a>
                                    <p>{{$comment->note}}</p>
                                    <h6 class="light-blue-text">{{$comment->user->username}}</h6>
                                    <p>{{$comment->created_at->diffForHumans()}}</p>
                                    @if($comment->user->id ==Auth::id())
                                    <div class="commentdetails">
                                        <a href="{{route('accrequest.edit', ['id'=>$comment->id])}}" class="btn btn-primary"><i class="fas fa fa-edit"></i></a>
                                        &nbsp;
                                        <a href="{{route('accrequest.delete', ['id'=>$comment->id])}}" class="btn btn-danger"><i class="fas fa fa-trash"></i></a>
                                    </div>
                                    @endif


                                </li>
                            </ul>
                            @endforeach

                            {{$comments->links()}}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    @include('includes.notification')
</body>

</html>