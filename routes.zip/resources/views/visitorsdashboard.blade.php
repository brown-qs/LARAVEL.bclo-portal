<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>BCLO</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <script src="{{asset('js/jquery-2.1.3.min.js')}}"></script>
    <script src="{{asset('assets/js/materialize.min.js')}}"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="{{asset('assets/css/font-awesome.min.css')}}">


    <!-- Styles -->

    <link href="{{ asset('css/toastr.min.css') }}" rel="stylesheet">
    <link href="{{asset('assets/css/materialize.min.css')}}" rel="stylesheet">
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{asset('assets/css/style.css')}}" rel="stylesheet">

</head>

<body>
    @include('includes.nav')

    <section class="py-5">
        <div class="container">
            <div class="row">
                <form class="input-field col s6" action="{{route('estate.search')}}" method="post">
                    {{csrf_field()}}
                    <i class="fa fa-search prefix"></i>
                    <input id="search_icon_prefix" type="text" class="validate" name="word" value="{{$search ?? ''}}" autofocus>
                    <label for="search_icon_prefix">Search Everything through Address, Phone number, or Name ...</label>
                </form>
            </div>
            <div class="row align-items-stretch">
                <div class="col-md-4 mb-4">
                    <a href="{{route('estate.create')}}" class="card btn waves-effect h-100" style="min-height: 200px;">
                        <div class="card-body d-flex justify-content-center">
                            <p class="my-auto h1">+</p>
                        </div>
                    </a>
                </div>
                @foreach ( $houses as $house )
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="img-responsive">
                                <!-- <img src="{{asset($house->picture)}}" class="img-fluid"> -->
                                <h3 class="mt-4 light-blue-text center">{{$house->first_name . ' ' . $house->last_name}}</h3>
                                <p class=" center">{{$house->address}}</p>
                                <p class="light-blue-text center"><i class="fas fa fa-user"></i>{{$house->user->name}} &nbsp; <i class="fas fa fa-history"></i>{{$house->created_at->diffForHumans()}} </p>

                                <hr>

                                <div class="text-center">
                                    <a href="{{route('frontend.singlehouse', ['id' =>$house->id])}}" class="btn light-blue darken-1 btn-block white-text">more info</a>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach

            </div>
            {{$houses->links()}}
        </div>
    </section>

    @include('includes.notification')


</body>

</html>