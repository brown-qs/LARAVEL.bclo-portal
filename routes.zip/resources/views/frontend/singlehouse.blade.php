<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>BCLO</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <script src="{{asset('js/jquery-2.1.3.min.js')}}"></script>
    <script src="{{asset('assets/js/materialize.min.js')}}"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="{{asset('assets/css/font-awesome.min.css')}}">


    <!-- Styles -->

    <link href="{{ asset('css/toastr.min.css') }}" rel="stylesheet">
    <link href="{{asset('assets/css/materialize.min.css')}}" rel="stylesheet">
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{asset('assets/css/style.css')}}" rel="stylesheet">

</head>

<body>
    @include('includes.nav')
    <section class="py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="d-flex justify-content-between">
                        <a href="/dashboard" class="btn btn-lg btn-default">Back to Search</a>
                        <a href="{{route('estate.edit', ['id'=>$house->id])}}" class="btn btn-lg btn-warning"><i class="fa fa-pencil"></i></a>
                    </div>
                    <ul class="list-group list-group-flush mt-4">
                        <li class="list-group-item text-secondary">
                            Land ID :
                            <span class="float-right">{{$house->land_id}}</span>
                        </li>

                        <li class="list-group-item text-secondary">
                            Owner Dues Paid? :
                            <span class="float-right">{{$house->is_paid ? 'Paid' : 'No'}}</span>
                        </li>
                        <li class="list-group-item text-secondary">
                            Owner has Mail Box? :
                            <span class="float-right">{{$house->has_mailbox ? 'Yes' : 'No'}}</span>
                        </li>
                        <li class="list-group-item text-secondary">
                            Phone Number :
                            <span class="float-right">{{$house->phone}}</span>
                        </li>
                        <li class="list-group-item text-secondary">
                            Email :
                            <span class="float-right">{{$house->email}}</span>
                        </li>
                        <li class="list-group-item text-secondary">
                            Name :
                            <span class="float-right">{{$house->first_name.' '.$house->last_name}}</span>
                        </li>
                        <li class="list-group-item text-secondary">
                            Address :
                            <span class="float-right">{{$house->address}}</span>
                        </li>
                    </ul>
                    <div class="white-text mt-5 d-flex justify-content-center">
                        <a href="{{route('accrequest.create', ['id' => $house->id])}}" class="btn btn-primary mx-2" title="Request Acc"><i class="fa fa-send"></i></a>
                        <a href="{{route('letter.create', ['id' => $house->id])}}" class="btn btn-success mx-2" title="Letter"><i class="fa fa-envelope"></i></a>
                        <a href="{{route('comment.create', ['id' => $house->id])}}" class="btn btn-danger mx-2" title="Note"><i class="fa fa-edit"></i></a>
                    </div>

                </div>
            </div>
    </section>
    @include('includes.notification')
</body>

</html>