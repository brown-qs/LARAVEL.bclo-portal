<header>
    <nav class="nav-wrapper light-blue darken-1">
        <div class="container">
            @if(!Auth::user())
            <a href="/" class="brand-logo">BCLO</a>
            @else
            <a href="/dashboard" class="brand-logo">BCLO</a>
            @endif

            @if(!Auth::user())
            <ul class="right hide-on-med-and-down">
                <li><a href="{{route('login')}}">Log in</a></li>
            </ul>
            @else
            <ul class="right hide-on-med-and-down">
                <li><a href="/dashboard">Home</a></li>
                <li><a href="">{{Auth::user()->username}}</a></li>
                <li>

                    <a href="{{route('logout')}}" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">

                        Logout

                    </a>
                </li>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                    @csrf
                </form>
            </ul>
            @endif
        </div>
    </nav>
</header>